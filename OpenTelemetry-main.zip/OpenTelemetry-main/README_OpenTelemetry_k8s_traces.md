# Monitoring Kubernetes Traces via Open Telemetry Collector 
Reference Documentation: https://opentelemetry.io/docs/

# 1. Install Collector Agent and application on Minikube cluster:  

    cd otel_traces
    kubectl apply -k .



